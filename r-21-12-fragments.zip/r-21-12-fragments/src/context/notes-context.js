import React from 'react'

const NotesContext = React.createContext()

export { NotesContext as default }